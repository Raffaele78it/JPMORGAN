package caller;

import java.math.BigDecimal;

import jpMorgan.datamodel.StockType;
import jpMorgan.datamodel.Trade;
import jpMorgan.datamodel.TreaderType;
import jpMorgan.simple.stock.JPMorganSimpleStockImpl;

public class caller {

	
	public  static void main(String[] args) {
			
		
		JPMorganSimpleStockImpl yy =new  JPMorganSimpleStockImpl();
		
		Trade p = new Trade("TEA", java.sql.Timestamp.valueOf("2005-02-25 11:50:11.579"), 10, 
				StockType.COMMON, new BigDecimal("1115.37"), TreaderType.BUYER);
		
		 yy.saveTheTrade(p.getSymbol(), p.getTradeTimestamp(), p.getTradeQuantity(), p.getStock(), p.getStockPrice(), p.getTraderType());
		p=new Trade("TEA", java.sql.Timestamp.valueOf("2005-02-25 12:02:11.579"), 10, 
				StockType.COMMON, new BigDecimal("1115.37"),TreaderType.BUYER);
		yy.saveTheTrade(p.getSymbol(), p.getTradeTimestamp(), p.getTradeQuantity(), p.getStock(), p.getStockPrice(), p.getTraderType());
		
		p=new Trade("TEA", java.sql.Timestamp.valueOf("2005-02-25 12:03:11.579"), 10, 
				StockType.COMMON, new BigDecimal("1115.37"),TreaderType.BUYER);
		yy.saveTheTrade(p.getSymbol(), p.getTradeTimestamp(), p.getTradeQuantity(), p.getStock(), p.getStockPrice(), p.getTraderType());

		p=new Trade("TEA", java.sql.Timestamp.valueOf("2005-02-25 12:10:11.579"), 10, 
				StockType.COMMON, new BigDecimal("1115.37"),TreaderType.BUYER);
		yy.saveTheTrade(p.getSymbol(), p.getTradeTimestamp(), p.getTradeQuantity(), p.getStock(), p.getStockPrice(), p.getTraderType());
		
		yy.calculateStockPrice15(p.getSymbol());
		yy.dividendYesld("GIN", StockType.PREFERED);
		yy.dividendYesld("TEAS", StockType.COMMON);

		yy.peRatio("TEA");
		yy.GBCEAllShareIndex();
		
		
	}
	
	
	

}
