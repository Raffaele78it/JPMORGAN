package jpMorgan.datamodel;

public enum StockType {
	
	COMMON, PREFERED;
	

}
