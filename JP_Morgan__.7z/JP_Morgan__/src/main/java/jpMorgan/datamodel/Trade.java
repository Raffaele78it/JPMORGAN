package jpMorgan.datamodel;

import java.math.BigDecimal;
import java.sql.Timestamp;

public class Trade {

	
	private String Symbol; 
	private Timestamp tradeTimestamp ; 
	private int tradeQuantity ;
	private StockType stock;
	private BigDecimal stockPrice;
	private TreaderType traderType;
	
	
		
	public Trade(String symbol, Timestamp tradeTimestamp, int tradeQuantity, StockType stock, BigDecimal stockPrice, TreaderType traderType) {
		super();
		Symbol = symbol;
		this.tradeTimestamp = tradeTimestamp;
		this.tradeQuantity = tradeQuantity;
		this.stock = stock;
		this.stockPrice = stockPrice;
		this.traderType= traderType;
	}
	
	public String getSymbol() {
		return Symbol;
	}
	public void setSymbol(String symbol) {
		Symbol = symbol;
	}
	public Timestamp getTradeTimestamp() {
		return tradeTimestamp;
	}
	public void setTradeTimestamp(Timestamp tradeTimestamp) {
		this.tradeTimestamp = tradeTimestamp;
	}
	public int getTradeQuantity() {
		return tradeQuantity;
	}
	public void setTradeQuantity(int tradeQuantity) {
		this.tradeQuantity = tradeQuantity;
	}
	public StockType getStock() {
		return stock;
	}
	public void setStock(StockType stock) {
		this.stock = stock;
	}
	public BigDecimal getStockPrice() {
		return stockPrice;
	}
	public void setStockPrice(BigDecimal stockPrice) {
		this.stockPrice = stockPrice;
	}

	public TreaderType getTraderType() {
		return traderType;
	}

	public void setTraderType(TreaderType traderType) {
		this.traderType = traderType;
	}

	
	
	
	
	
	
		
	
	
}
