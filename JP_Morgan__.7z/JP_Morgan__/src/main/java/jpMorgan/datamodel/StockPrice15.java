package jpMorgan.datamodel;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;

public class StockPrice15 {

	private String stockSymbol="";
	private ArrayList<Timestamp> timeStamps15=new  ArrayList<Timestamp>();
	private ArrayList<BigDecimal> price15=new ArrayList<BigDecimal>();
	private ArrayList<BigDecimal> qty15=new ArrayList<BigDecimal>();

	public StockPrice15(){

	}	

	public boolean  addSingleTimeStamp(Timestamp s){		
		return timeStamps15.add(s);
	}
	public boolean addSinglePrice(BigDecimal d){
		return price15.add(d);		 
	}
	public boolean addSingleQuantity(BigDecimal i){
		return qty15.add(i);
	}

	
	

	
	public ArrayList<BigDecimal> getQty15() {
		return qty15;
	}

	public void setQty15(ArrayList<BigDecimal> qty15) {
		this.qty15 = qty15;
	}

	public String getStockSymbol() {
		return stockSymbol;
	}
	public void setStockSymbol(String stockSymbol) {
		this.stockSymbol = stockSymbol;
	}
	public ArrayList<Timestamp> getTimeStams15() {
		return timeStamps15;
	}
	public void setTimeStams15(ArrayList<Timestamp> timeStamps15) {
		this.timeStamps15 = timeStamps15;
	}
	public ArrayList<BigDecimal> getPrice15() {
		return price15;
	}
	public void setPrice15(ArrayList<BigDecimal> price15) {
		this.price15 = price15;
	}



}
