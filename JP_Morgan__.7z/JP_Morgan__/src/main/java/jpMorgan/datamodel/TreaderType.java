package jpMorgan.datamodel;

public enum TreaderType {

	BUYER, SELLER;
}
