package jpMorgan.datamodel.mock;

import java.math.BigDecimal;
import java.util.HashMap;

import jpMorgan.datamodel.Stock;
import jpMorgan.datamodel.StockType;

public class StockMainDataMock {

	
	public static  HashMap <String, Stock> stockMainDataLoading(HashMap <String, Stock> stockMainData){
		Stock stock= new Stock();
		stock.setFixedDividend(new BigDecimal("2"));
		stock.setLastDividend(new BigDecimal("8"));
		stock.setParValue(new BigDecimal("100"));
		stock.setSymbol("GIN");
		stock.setStockType(StockType.PREFERED);
		stockMainData.put(stock.getSymbol(), stock);

		Stock stock2= new Stock();
		stock2.setFixedDividend(new BigDecimal("0"));
		stock2.setLastDividend(new BigDecimal("0"));
		stock2.setParValue(new BigDecimal("100"));
		stock2.setSymbol("TEA");
		stock2.setStockType(StockType.COMMON);
		stockMainData.put(stock2.getSymbol(), stock2);

		Stock stock3= new Stock();
		stock3.setFixedDividend(new BigDecimal("0"));
		stock3.setLastDividend(new BigDecimal("8"));
		stock3.setParValue(new BigDecimal("100"));
		stock3.setSymbol("POP");
		stock3.setStockType(StockType.COMMON);
		stockMainData.put(stock3.getSymbol(), stock3);


		Stock stock4= new Stock();
		stock4.setFixedDividend(new BigDecimal("0"));
		stock4.setLastDividend(new BigDecimal("23"));
		stock4.setParValue(new BigDecimal("60"));
		stock4.setSymbol("ALE");
		stock4.setStockType(StockType.COMMON);
		stockMainData.put(stock4.getSymbol(), stock4);

		Stock stock5= new Stock();
		stock5.setFixedDividend(new BigDecimal("0"));
		stock5.setLastDividend(new BigDecimal("13"));
		stock5.setParValue(new BigDecimal("250"));
		stock5.setSymbol("JOE");
		stock5.setStockType(StockType.COMMON);
		stockMainData.put(stock5.getSymbol(), stock5);

		return stockMainData; 

	}

}
