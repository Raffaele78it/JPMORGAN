package jpMorgan.simple.stock;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;

import org.apache.log4j.Logger;

import jpMorgan.datamodel.Stock;
import jpMorgan.datamodel.StockPrice15;
import jpMorgan.datamodel.StockType;
import jpMorgan.datamodel.Trade;
import jpMorgan.datamodel.TreaderType;
import jpMorgan.datamodel.mock.StockMainDataMock;
import jpMorgan.simple.stock.utility.SimpleStockUtilities;

public class JPMorganSimpleStockImpl implements JPMorganSimpleStock{

	final static Logger logger = Logger.getLogger(JPMorganSimpleStockImpl.class);
	private BigDecimal defaultReturned =new BigDecimal("0");
	private SimpleStockUtilities simpleStockUtilities = new SimpleStockUtilities();

	private HashMap <String, Stock> stockMainData;
	private HashMap <String, Trade> mapOfTrades ;
	private HashMap <String, StockPrice15>mapOfTrades15Evo;

	public JPMorganSimpleStockImpl(){
		this.mapOfTrades= new HashMap<String, Trade>();
		this.mapOfTrades15Evo=new HashMap <String, StockPrice15>();
		this.stockMainData=new HashMap <String, Stock>();

	}

	@Override
	public double GBCEAllShareIndex(){
		logger.info("GBCEAllShareIndex invoked");
		ArrayList <BigDecimal> priceListForGBCE = new ArrayList<BigDecimal>();
		for(String s :mapOfTrades15Evo.keySet()){
			priceListForGBCE.addAll((mapOfTrades15Evo.get(s)).getPrice15());
		}
		BigDecimal pricesProduct = priceListForGBCE.get(0);
		for(int i=1; i<priceListForGBCE.size();i++){
			pricesProduct=pricesProduct.multiply(priceListForGBCE.get(i));
		}
		double d =Math.pow(pricesProduct.doubleValue(),(1/new Double(priceListForGBCE.size())));
		logger.debug("Index Value Calculated "+d);
		return d;
	}

	//a.I
	@Override
	public BigDecimal dividendYesld(String symbol, StockType stp) {
		logger.info("dividendYesld invoked for "+symbol+" type: "+stp);
		BigDecimal retValue=null; 
		stockMainData = StockMainDataMock.stockMainDataLoading(stockMainData);
		if(simpleStockUtilities.checkTheStock(symbol, stockMainData, mapOfTrades)){		
			switch  (stp){
			case  COMMON:
				retValue= ((stockMainData.get(symbol)).getLastDividend()).divide(simpleStockUtilities.tickerPriceCalculation(symbol,stockMainData));
				break; 
			case PREFERED:
				retValue=(((stockMainData.get(symbol)).getFixedDividend()).multiply((stockMainData.get(symbol)).getParValue())).divide(simpleStockUtilities.tickerPriceCalculation(symbol,stockMainData));
				break;
			}
			logger.debug("Dividend calculated "+retValue);
			return retValue;
		}else {
			logger.error("dividendYesld completed with error default value returned : "+defaultReturned);
			return defaultReturned;
		}
	}

	//a.II
	@Override
	public BigDecimal peRatio(String symbol) {	
		logger.info("peRatio invoked for "+symbol);
		BigDecimal retValue=null; 
		if(simpleStockUtilities.checkTheStock(symbol, stockMainData, mapOfTrades)){
			if(((stockMainData.get(symbol)).getLastDividend()).intValue()!=0){
				retValue = (simpleStockUtilities.tickerPriceCalculation(symbol,stockMainData)).divide(((stockMainData.get(symbol)).getLastDividend()));
				logger.debug("peRatio - P/E calculated "+retValue);
				return retValue;
			}else{
				logger.info("peRatio - The dividend was zero, default value returned "+defaultReturned);
				return defaultReturned;
			}
		}else {
			logger.error("peRatio Completed with error default value returned "+defaultReturned);
			return defaultReturned; 
		}
	}

	//a.III
	@Override
	public boolean saveTheTrade(String symbol,Timestamp timeStamp, int quantity, StockType stockType, BigDecimal stockPrice, TreaderType traderType) {
		logger.info("saveTheTrade invoked for "+symbol);
		Trade t = new Trade(symbol, timeStamp,quantity,stockType,stockPrice, traderType);
		return simpleStockUtilities.stockPush(symbol, t, mapOfTrades, mapOfTrades15Evo);
	}

	//a.IV
	@Override
	public BigDecimal calculateStockPrice15(String stockSymbol) {			

		BigDecimal resultValueNum = new BigDecimal(0);
		BigDecimal resultValueDenom = new BigDecimal(0);
		for (int i=0; i<(mapOfTrades15Evo.get(stockSymbol)).getPrice15().size(); i++){
			resultValueNum= resultValueNum.add((mapOfTrades15Evo.get(stockSymbol)).getPrice15().get(i).multiply((mapOfTrades15Evo.get(stockSymbol)).getQty15().get(i)));
			resultValueDenom= resultValueDenom.add((mapOfTrades15Evo.get(stockSymbol)).getQty15().get(i));
		}		
		return resultValueNum.divide(resultValueDenom); 
	}


}
