package jpMorgan.simple.stock;

import java.math.BigDecimal;
import java.sql.Timestamp;

import jpMorgan.datamodel.StockType;
import jpMorgan.datamodel.TreaderType;

public interface JPMorganSimpleStock {
	
	public boolean saveTheTrade(String Symbol, Timestamp TimeStamp, int quantity, StockType stockType, BigDecimal stockPrice,TreaderType traderType);
	
	public BigDecimal calculateStockPrice15 (String stockSymbol);
	
	
	public BigDecimal dividendYesld(String symbol, StockType stp);
	
	public BigDecimal peRatio(String symbol);
	public double GBCEAllShareIndex();
	

}
