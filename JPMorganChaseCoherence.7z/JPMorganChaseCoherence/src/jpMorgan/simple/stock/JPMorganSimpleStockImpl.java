package jpMorgan.simple.stock;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.HashMap;

import jpMorgan.coherence.connector.CoherenceConnector;
import jpMorgan.datamodel.StockPrice15;
import jpMorgan.datamodel.Trade;
import jpMorgan.simple.stock.utility.SimpleStockUtilities;

import org.apache.log4j.Logger;

import com.tangosol.net.NamedCache;

public class JPMorganSimpleStockImpl {
	final static Logger logger = Logger.getLogger(JPMorganSimpleStockImpl.class);

	private NamedCache myCache; 
	//	private HashMap <String, Stock> stockMainData;
	private HashMap <String, Trade> mapOfTrades ;
	private HashMap <String, StockPrice15>mapOfTrades15Evo;
	private SimpleStockUtilities simpleStockUtilities = new SimpleStockUtilities();


	public JPMorganSimpleStockImpl(){
		this.mapOfTrades= new HashMap<String, Trade>();
		this.mapOfTrades15Evo=new HashMap <String, StockPrice15>();
		//		this.stockMainData=new HashMap <String, Stock>();
		CoherenceConnector cConn = new CoherenceConnector();
		myCache = cConn.getCache("JP_StockCache");		

	}

	//a.III
	public boolean saveTheTrade(String symbol,Timestamp timeStamp, int quantity, String stockType, BigDecimal stockPrice, String traderType) {
		logger.info("saveTheTrade invoked for "+symbol);
		Trade t = new Trade(symbol, timeStamp,quantity,stockType,stockPrice, traderType);

		if(simpleStockUtilities.stockPush("TEA", t, mapOfTrades, mapOfTrades15Evo)){
			myCache.put("mapOfTrades", mapOfTrades);
			myCache.put("mapOfTrades15Evo", mapOfTrades15Evo);
			logger.info("mapOfTrades.keySet() "+mapOfTrades.keySet());
			return true;
		}
		return false;
	}





}
