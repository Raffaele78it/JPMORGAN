package jpMorgan.simple.stock.utility;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.HashMap;

import org.apache.log4j.Logger;

import jpMorgan.datamodel.Stock;
import jpMorgan.datamodel.StockPrice15;
import jpMorgan.datamodel.Trade;

public class SimpleStockUtilities {

	final static Logger logger = Logger.getLogger(SimpleStockUtilities.class);

	public boolean  stockPush(String symbol , Trade o ,HashMap <String, Trade> mapOfTrades ,HashMap <String, StockPrice15>mapOfTrades15Evo){
		logger.info("stockPush invoked");
		if(mapOfTrades.get(symbol)==null){
			StockPrice15 s = new StockPrice15();
			s.addSinglePrice(o.getStockPrice());
			s.addSingleTimeStamp(new Timestamp(o.getTradeTimestamp()));
			s.addSingleQuantity(new BigDecimal(o.getTradeQuantity()));
			s.setStockSymbol(symbol);

			mapOfTrades15Evo.put(symbol, s);
			mapOfTrades.put(symbol, o);
		}else{				
			minutesCheck15EVO(mapOfTrades15Evo,o);
			mapOfTrades.put(symbol, o);
		}
		
		logger.info("stockPush Completed with success");

		return true;

	}
	public BigDecimal tickerPriceCalculation(String symbol,HashMap <String, Stock> stockMainData){
		return ((stockMainData.get(symbol)).getParValue().multiply(new BigDecimal("0.1"))).divide(new BigDecimal("100"));
	}


	public long diffSeconds(Timestamp t1, Timestamp t2){	
		return ((t2.getTime() - t1.getTime()));		
	}

	public boolean minutes15Fitting(HashMap <String, StockPrice15>mapOfTrades15Evo, Trade t){
		while((diffSeconds(mapOfTrades15Evo.get(t.getSymbol()).getTimeStams15().get(0), 
				mapOfTrades15Evo.get(t.getSymbol()).getTimeStams15().get(mapOfTrades15Evo.get(t.getSymbol()).getTimeStams15().size()-1))/1000)>900){
			(mapOfTrades15Evo.get(t.getSymbol())).getTimeStams15().remove(0);
			(mapOfTrades15Evo.get(t.getSymbol())).getPrice15().remove(0);
			(mapOfTrades15Evo.get(t.getSymbol())).getQty15().remove(0);
		}
		return false;

	}
	
	public boolean headPositionRemoving(HashMap <String, StockPrice15>mapOfTrades15Evo,Trade t){
//		logger.debug("headPositionRemoving invoked ");
		(mapOfTrades15Evo.get(t.getSymbol())).getTimeStams15().remove(0);
		(mapOfTrades15Evo.get(t.getSymbol())).getPrice15().remove(0);
		(mapOfTrades15Evo.get(t.getSymbol())).getQty15().remove(0);
		return true;
	}
	public boolean  mapOfTrade15Adding(HashMap <String, StockPrice15>mapOfTrades15Evo,Trade t){
//		logger.debug("mapOfTrade15Adding invoked ");
		mapOfTrades15Evo.get(t.getSymbol()).getTimeStams15().add(new Timestamp(t.getTradeTimestamp()));
		mapOfTrades15Evo.get(t.getSymbol()).getPrice15().add(t.getStockPrice());
		mapOfTrades15Evo.get(t.getSymbol()).getQty15().add(new BigDecimal(t.getTradeQuantity()));
		return true;
	}

	public boolean minutesCheck15EVO (HashMap <String, StockPrice15>mapOfTrades15Evo , Trade t){			
//		logger.debug("minutesCheck15EVO invoked ");

		if(new Timestamp(t.getTradeTimestamp()).after(mapOfTrades15Evo.get(t.getSymbol()).getTimeStams15().get(mapOfTrades15Evo.get(t.getSymbol()).getTimeStams15().size()-1))
				&&
				((diffSeconds(mapOfTrades15Evo.get(t.getSymbol()).getTimeStams15().get(0), 
						mapOfTrades15Evo.get(t.getSymbol()).getTimeStams15().get(mapOfTrades15Evo.get(t.getSymbol()).getTimeStams15().size()-1)))/1000)>=900){

			headPositionRemoving(mapOfTrades15Evo, t);
			minutes15Fitting(mapOfTrades15Evo , t );
			mapOfTrade15Adding(mapOfTrades15Evo, t);

		}
		mapOfTrade15Adding(mapOfTrades15Evo, t);
		long hh = (diffSeconds(mapOfTrades15Evo.get(t.getSymbol()).getTimeStams15().get(0), 
				mapOfTrades15Evo.get(t.getSymbol()).getTimeStams15().get(mapOfTrades15Evo.get(t.getSymbol()).getTimeStams15().size()-1)))/1000;
		if(hh>900) minutes15Fitting(mapOfTrades15Evo , t );
		return true;
	}



	public boolean checkTheStock(String symbol,HashMap <String, Stock> stockMainData,HashMap <String, Trade> mapOfTrades){
		if((stockMainData.get(symbol)==null)&&(mapOfTrades.get(symbol)==null)){
//			logger.error("checkTheStock : The stock "+symbol+" doesn't exist");
			return false;
		}
		return true;
	}

}
