package jpMorgan.datamodel;


import java.io.IOException;
import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import com.tangosol.io.pof.PofReader;
import com.tangosol.io.pof.PofWriter;
import com.tangosol.io.pof.PortableObject;
import com.tangosol.util.Base;
import com.tangosol.util.HashHelper;


public class Trade implements PortableObject, Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String Symbol; 
	private long tradeTimestamp ; 
	private int tradeQuantity ;
	private String stock;
	private BigDecimal stockPrice;
	private String traderType;
	
	
		
	public Trade(String symbol, Timestamp tradeTimestamp, int tradeQuantity, String stock, BigDecimal stockPrice, String traderType) {
		super();
		Symbol = symbol;
		this.tradeTimestamp = tradeTimestamp.getTime();
		this.tradeQuantity = tradeQuantity;
		this.stock = stock;
		this.stockPrice = stockPrice;
		this.traderType= traderType;
	}
	
	public String getSymbol() {
		return Symbol;
	}
	public void setSymbol(String symbol) {
		Symbol = symbol;
	}
	public long getTradeTimestamp() {
		return tradeTimestamp;
	}

	public void setTradeTimestamp(long tradeTimestamp) {
		this.tradeTimestamp = tradeTimestamp;
	}

	public int getTradeQuantity() {
		return tradeQuantity;
	}
	public void setTradeQuantity(int tradeQuantity) {
		this.tradeQuantity = tradeQuantity;
	}
	public String getStock() {
		return stock;
	}
	public void setStock(String stock) {
		this.stock = stock;
	}
	public BigDecimal getStockPrice() {
		return stockPrice;
	}
	public void setStockPrice(BigDecimal stockPrice) {
		this.stockPrice = stockPrice;
	}

	public String getTraderType() {
		return traderType;
	}

	public void setTraderType(String traderType) {
		this.traderType = traderType;
	}

	
	
	@Override
	public void readExternal(PofReader reader) throws IOException {
			setSymbol(reader.readString(0));
			setTradeTimestamp(reader.readLong(1));
			setTradeQuantity(reader.readInt(2));
			setStock(reader.readString(3));
			setStockPrice(reader.readBigDecimal(4));
			setTraderType(reader.readString(5));
			
	}

	@Override
	public void writeExternal(PofWriter writer) throws IOException {
		 writer.writeString	(0, getSymbol());
		 writer.writeLong	(1, getTradeTimestamp());
		 writer.writeInt	(2, getTradeQuantity());
		 writer.writeString	(3, getStock());
		 writer.writeBigDecimal(4, getStockPrice());
		 writer.writeString	(5, getTraderType());
		 
	}

	public boolean equals(Object oThat)
    {
    if (this == oThat)
        {
        return true;
        }
    if (oThat == null)
        {
        return false;
        }

    Trade that = (Trade) oThat;
    return Base.equals(getSymbol(), 		that.getSymbol()) &&
           Base.equals(getTradeTimestamp(), that.getTradeTimestamp()) &&
           Base.equals(getTradeQuantity(),  that.getTradeQuantity())    &&
           Base.equals(getStock(),   		that.getStock())   &&
           Base.equals(getStockPrice(),     that.getStockPrice())     &&
           Base.equals(getTraderType(), 	that.getTraderType());
    }
	
	public int hashCode()
    {
    return HashHelper.hash(getSymbol(),
           HashHelper.hash(getTradeTimestamp(),
           HashHelper.hash(getTradeQuantity(), 0)));
    }
	
	
	
	
}
