package jpMorgan.datamodel;

import java.io.IOException;
import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;

import com.tangosol.io.pof.PofReader;
import com.tangosol.io.pof.PofWriter;
import com.tangosol.io.pof.PortableObject;
import com.tangosol.util.Base;
import com.tangosol.util.HashHelper;

public class StockPrice15 implements PortableObject, Serializable{
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 3886815181051949082L;
	private String stockSymbol="";
	private ArrayList<Timestamp> timeStamps15=new  ArrayList<Timestamp>();
	private ArrayList<BigDecimal> price15=new ArrayList<BigDecimal>();
	private ArrayList<BigDecimal> qty15=new ArrayList<BigDecimal>();

	public StockPrice15(){

	}	

	public boolean  addSingleTimeStamp(Timestamp s){		
		return timeStamps15.add(s);
	}
	public boolean addSinglePrice(BigDecimal d){
		return price15.add(d);		 
	}
	public boolean addSingleQuantity(BigDecimal i){
		return qty15.add(i);
	}

	
	

	
	public ArrayList<BigDecimal> getQty15() {
		return qty15;
	}

	public void setQty15(ArrayList<BigDecimal> qty15) {
		this.qty15 = qty15;
	}

	public String getStockSymbol() {
		return stockSymbol;
	}
	public void setStockSymbol(String stockSymbol) {
		this.stockSymbol = stockSymbol;
	}
	public ArrayList<Timestamp> getTimeStams15() {
		return timeStamps15;
	}
	public void setTimeStams15(ArrayList<Timestamp> timeStamps15) {
		this.timeStamps15 = timeStamps15;
	}
	public ArrayList<BigDecimal> getPrice15() {
		return price15;
	}
	public void setPrice15(ArrayList<BigDecimal> price15) {
		this.price15 = price15;
	}
	
	public ArrayList<Timestamp> getTimeStamps15() {
		return timeStamps15;
	}

	public void setTimeStamps15(ArrayList<Timestamp> timeStamps15) {
		this.timeStamps15 = timeStamps15;
	}

	

	@Override
	public void readExternal(PofReader reader) throws IOException {
		setStockSymbol(reader.readString(0));
		setTimeStams15((ArrayList<Timestamp>) reader.readObject(1));
		setPrice15((ArrayList<BigDecimal>) reader.readObject(2));
		setQty15((ArrayList<BigDecimal>) reader.readObject(3));
	}

	@Override
	public void writeExternal(PofWriter writer) throws IOException {
		writer.writeString(0, getStockSymbol());
		writer.writeObject(1, getTimeStamps15());
		writer.writeObject(2, getPrice15());
		writer.writeObject(3, getQty15());
	}


}
