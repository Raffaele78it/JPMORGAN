package jpMorgan.datamodel;

import java.io.IOException;
import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;

import com.tangosol.io.pof.PofReader;
import com.tangosol.io.pof.PofWriter;
import com.tangosol.io.pof.PortableObject;
import com.tangosol.util.Base;
import com.tangosol.util.HashHelper;

public class Stock implements PortableObject, Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -3905460103081698369L;
	private String symbol;
	private StockType stockType;
	private BigDecimal lastDividend; 
	private BigDecimal fixedDividend; 
	private BigDecimal parValue;
	public String getSymbol() {
		return symbol;
	}
	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}
	public StockType getStockType() {
		return stockType;
	}
	public void setStockType(StockType stockType) {
		this.stockType = stockType;
	}
	public BigDecimal getLastDividend() {
		return lastDividend;
	}
	public void setLastDividend(BigDecimal lastDividend) {
		this.lastDividend = lastDividend;
	}
	public BigDecimal getFixedDividend() {
		return fixedDividend;
	}
	public void setFixedDividend(BigDecimal fixedDividend) {
		this.fixedDividend = fixedDividend;
	}
	public BigDecimal getParValue() {
		return parValue;
	}
	public void setParValue(BigDecimal parValue) {
		this.parValue = parValue;
	}
	
	
	@Override
	public void readExternal(PofReader reader) throws IOException {
		setSymbol(reader.readString(0));
		setLastDividend(reader.readBigDecimal(1));
		setFixedDividend(reader.readBigDecimal(2));
		setParValue(reader.readBigDecimal(3));
		
	}
	@Override
	public void writeExternal(PofWriter writer) throws IOException {
		writer.writeString(0, 	  getSymbol());
		writer.writeBigDecimal(1, getLastDividend());
		writer.writeBigDecimal(2, getFixedDividend());
		writer.writeBigDecimal(3, getParValue());
	}
	
	public boolean equals(Object oThat)
    {
    if (this == oThat)
        {
        return true;
        }
    if (oThat == null)
        {
        return false;
        }

    Stock that = (Stock) oThat;
    return Base.equals(getSymbol(), 		that.getSymbol()) &&
           Base.equals(getLastDividend(), 	that.getLastDividend()) &&
           Base.equals(getFixedDividend(),  that.getFixedDividend())    &&
           Base.equals(getParValue(),   	that.getParValue());
    }
	
	public int hashCode()
    {
    return HashHelper.hash(getSymbol(),0);
    }

}
