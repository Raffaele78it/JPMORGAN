package jpMorgan.coherence.connector;

import com.tangosol.net.CacheFactory;
import com.tangosol.net.NamedCache;

public class CoherenceConnector {
	
public NamedCache getCache(String cacheName){
		
		CacheFactory.ensureCluster();
//		System.out.println("prima di named cache");
		NamedCache cache = CacheFactory.getCache(cacheName);
//		System.out.println("dopo namend cache");
		
		return cache;
	}

}
