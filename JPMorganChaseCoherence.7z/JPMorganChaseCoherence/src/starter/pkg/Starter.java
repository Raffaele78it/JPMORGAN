package starter.pkg;

import java.math.BigDecimal;
import java.sql.Timestamp;

import jpMorgan.datamodel.Trade;
import jpMorgan.simple.stock.JPMorganSimpleStockImpl;

public class Starter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		JPMorganSimpleStockImpl nm = new JPMorganSimpleStockImpl();

		Trade p = new Trade("TEA", java.sql.Timestamp.valueOf("2005-02-25 11:50:11.579"), 10, 
				"COMMON", new BigDecimal("1115.37"), "BUYER");
		nm.saveTheTrade(p.getSymbol(), new Timestamp(p.getTradeTimestamp()), p.getTradeQuantity(), p.getStock(), p.getStockPrice(), p.getTraderType());

	}

}
